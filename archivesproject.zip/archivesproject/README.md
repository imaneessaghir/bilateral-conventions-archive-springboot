# Projet Archives Spring Boot

## Description

Cette application permet de gérer les accords bilatéraux archivés, avec une gestion des documents PDF associés.  
Le projet est réalisé avec Spring Boot, Thymeleaf, MySQL.

---

## Prérequis

- Java JDK 17 ou supérieur
- MySQL installé et en fonctionnement
- (Optionnel) phpMyAdmin pour gérer la base de données

---

## Installation et lancement

### 1. Créer la base de données

- Ouvrir phpMyAdmin ou un terminal MySQL
- Créer une base de données nommée `archives_db` (ou autre nom, à adapter dans `application.properties`)
- Importer le fichier SQL `database/archives_db.sql` fourni avec le projet

Exemple en terminal :
```bash
mysql -u root -p archives_db < database/archives_db.sql
