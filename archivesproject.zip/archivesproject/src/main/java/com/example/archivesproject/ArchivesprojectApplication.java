package com.example.archivesproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArchivesprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArchivesprojectApplication.class, args);
	}

}
